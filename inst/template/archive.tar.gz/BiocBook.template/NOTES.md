[x] Add helper function to set up serving from GH pages
[x] Add function for local rendering
[x] Add function for publishing

[x] add a pre-commit hook to scrape dependencies in files from `inst/pages/`

[ ] add shortcut link in root of `gh-pages`
