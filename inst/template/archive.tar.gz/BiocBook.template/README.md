<!-- badges: start -->
📦 [Repo](https://github.com/<github_user>/<Package_name>) [![rworkflows](https://img.shields.io/github/actions/workflow/status/<github_user>/<Package_name>/rworkflows.yml?label=Package%20check)](https://github.com/<github_user>/<Package_name>/actions/workflows/rworkflows.yml)   
📖 [Book](https://<github_user>.github.io/<Package_name>/devel) [![deployment](https://img.shields.io/github/actions/workflow/status/<github_user>/<Package_name>/pages/pages-build-deployment?label=Book%20deployment)](https://github.com/<github_user>/<Package_name>/actions/workflows/pages/pages-build-deployment)  
🐳 [Docker](https://github.com/<github_user>/<Package_name>/pkgs/container/<Package_name>) [![biocbook](https://img.shields.io/github/actions/workflow/status/<github_user>/<Package_name>/biocbook.yml?label=Docker%20image)](https://github.com/<github_user>/<Package_name>/actions/workflows/biocbook.yml)  
<!-- badges: end -->
